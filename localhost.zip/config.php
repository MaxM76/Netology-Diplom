<?php return [
	    'host' => 'localhost',
	    'dbname' => 'mmarkelov',
	    'user' => 'root',
	    'pass' => 'Ufdhbkf',
    ];

