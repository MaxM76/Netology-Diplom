  <body>
    <header>
      <div class="header-wrapper">
<?php include 'user.php';?>
<?php
    include 'menu.php';
    echo $eblock;
    echo $mblock;
?>
      </div>
    </header>

    <section class="main-section">
      <div class="main-section-wrapper">
<?php
    echo $oblock;
?>
      </div>
    </section>

    <footer>
      <div class="footer-wrapper">
        <p>
          © 2019  Максим Маркелов, по всем вопросам пишите по адресу <a href="mailto:m.v.markelov@mail.ru">
            m.v.markelov@mail.ru
          </a>
        </p>

          </td>
      </div>
    </footer>
  </body>