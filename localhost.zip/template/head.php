  <head>
	<meta charset="UTF-8">
	<title>Дипломный проект</title>
	<link rel="stylesheet" href="/css/styles.css">
  </head>