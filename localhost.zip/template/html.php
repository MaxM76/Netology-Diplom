<!DOCTYPE html>

<html lang="ru">

<?php
    include 'head.php';
    
    include 'body.php';
?>

</html>