<div style="border: 4px double black">
	<h1>Администрирование</h1>
	<p>Будучи администратором вы можете управлять пользователями и управлять контентом </p>

	<p><a href="?c=users&a=list">Управление пользователями</a></p>
	<p><a href="?c=topics&a=list">Управление контентом</a></p>
	<p><a href="?c=users&a=logout">Выйти</a></p>

</div>