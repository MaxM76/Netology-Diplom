<div>
	
<?php if (isset($intrusion)):?>
<?php echo $intrusion['block'];?>
<?php endif;?>

</div>